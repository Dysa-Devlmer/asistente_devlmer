<?php 
session_start();
if (!isset($_SESSION['id_camarero']))
	{
	exit(); 
	}
include "./conn.php";

function categorias()
	{
	include "./conn.php";	
	$salida = "";
	$cabecera = '<ul data-role="listview" data-theme="b">';
	$pie = "</ul>";
	
	$salida = $salida.$cabecera;
	// favoritos
	$salida = $salida.'<li><a href="#" onclick="showcatalogo(\'F\');">Favoritos</a></li>';
	$sql = "select id_tipo_comg,tipo_comg,imagen from tipo_comg where cafeteria = 'S' and visibleen = '0' and padre is null order by tipo_comg";
	$result = mysql_query($sql,$conexion);
	while ($row = mysql_fetch_array($result))
		{
		$salida = $salida.'<li><a href="#" onclick="$(\'.subcategorias\').empty();showcatalogo(\''.$row['id_tipo_comg'].'\')">';
		if (isset($row['imagen']))
			{
			$salida = $salida.'<img src="./imagecat.php?id='.$row['id_tipo_comg'].'" width="80" height="80" />';
			}
		$salida = $salida.$row['tipo_comg'].'</a></li><div id="'.$row['id_tipo_comg'].'" class="subcategorias"></div>';	
		}
	$salida = $salida.$pie;
	return $salida;
	}
	
?>

			<div data-role="header" data-position="fixed">
               <div data-role="navbar">
                    <ul>
                        <li>
							<a href="javascript:void(null);">
                                Cat&aacute;logo
                            </a>
                        </li>
                    </ul>
                </div>	
            </div>
			
            <div data-role="content">
				
				<div class="ui-grid-a">
					<div class="ui-block-a" style="width:40%;">
						<input type="search" name="busqueda" id="busqueda" value="" />
					</div>
					<div class="ui-block-b" style="width:60%;">
						<a href="#" onclick="showcatalogo('busqueda');" data-role="button" data-icon="search" data-inline="true">Buscar</a>
					</div>
				</div>
					
				<div class="ui-grid-a">
					<div class="ui-block-a" style="width:40%;">
					<?php 
					$contenido = categorias();
					echo $contenido; 
					?>
					</div>
					<div id="productos"class="ui-block-b" style="width:60%;">

					</div>
				</div>
	
			</div>
			
			<div data-role="footer" data-position="fixed">
               <div data-role="navbar" data-iconpos="top">
                    <ul>
                        <li>
                            <a href="#" onclick="cargaventa(<?php echo $_POST['id_venta']; ?>)" data-icon="back" >
                                Volver
                            </a>
                        </li>
                    </ul>
                </div>			
			</div>			
			
			<div data-role="popup" id="ficha_producto" data-theme="a" data-position-to="window" class="ui-content">
			
			</div>
			
<script>

	
	function showcatalogo(id)
		{
		if (id != 'busqueda')	
			{
			$('#'+id).load
				(
				'./sub_categorias.php',
				{
				padre: id
				},
				function() 
					{
					$('#'+id).trigger('create');
					}
				);	
			}

		$('#productos').load
			(
			'./productos.php',
			{
			padre: id,
			busqueda: $('#busqueda').attr('value'),
			id_venta:<?php echo $_POST['id_venta']; ?>
			},
			function() 
				{
				$('#productos').trigger('create');
				}
			);				
		}
		
		
	function plusone(id)
		{
		contador = contador + 1;
		if (contador == 11) {contador = 0;}
		$('#operaciones'+contador).load
			(
			'./save_producto.php',
			{
			add_producto: id,
			cantidad: 1,
			id_venta:<?php echo $_POST['id_venta']; ?>
			},
			function() 
				{
				$('#link'+id).prepend('<img src="./images/ok.png"/>');
				}
			);			
		}
		
	function ficha_producto(id)
		{
		$('#ficha_producto').load
			(
			'./add_producto.php',
			{
			producto: id,
			id_venta:<?php echo $_POST['id_venta']; ?>
			},
			function() 
				{
				$('#ficha_producto').trigger('create');
				$('#ficha_producto').popup('open');
				}
			);			
		}
</script>


 
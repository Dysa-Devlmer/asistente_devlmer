<?php 
session_start();
if (!isset($_SESSION['id_camarero']))
	{
	exit(); 
	}
include "./conn.php";
include "./".$_SESSION['idioma'].".php";

function categorias()
	{
	include "./conn.php";	
	$salida = "<div id='pbusqueda' class='subcategorias'></div>";
	$cabecera = '<ul data-role="listview" data-theme="b">';
	$pie = "</ul>";
	
	$salida = $salida.$cabecera;
	// favoritos
	$salida = $salida.'<li><a href="#" onclick="showcatalogo(\'F\');">';

	$salida = $salida.'<small>Favoritos</small></a></li><div id="pF" class="subcategorias"></div>';
	$sql = "select id_tipo_comg,tipo_comg,imagen from tipo_comg where cafeteria = 'S' and visibleen = '0' and padre is null order by tipo_comg";
	$result = mysql_query($sql,$conexion);
	while ($row = mysql_fetch_array($result))
		{
		$salida = $salida.'<li><a href="#" onclick="$(\'.subcategorias\').empty();showcatalogo(\''.$row['id_tipo_comg'].'\')">';
		$salida = $salida.'<small>'.$row['tipo_comg'].'</small></a></li><div id="'.$row['id_tipo_comg'].'" class="subcategorias"></div><div id="p'.$row['id_tipo_comg'].'" class="subcategorias"></div>';	
		}
	$salida = $salida.$pie;
	return $salida;
	}
	
?>




			
            <div data-role="content">
				

					<div class="ui-grid-a">
						<div class="ui-block-a">
							<input type="search" name="busqueda" id="busqueda" value="" />
						</div>
						<div class="ui-block-b">
							<a href="#" onclick="showcatalogo('busqueda');" data-role="button" data-icon="search"><?php echo $txtsearch; ?></a>
						</div>
					</div>
					<div id="productos">
						<?php 
						$contenido = categorias();
						echo $contenido; 
						?>
					</div>
	
			</div>
			
			<div data-role="footer" data-position="fixed">
               <div data-role="navbar" data-iconpos="top">
                    <ul>
                        <li>
                            <a href="#" onclick="cargaventa(<?php echo $_POST['id_venta']; ?>)" data-icon="back" >
                                <?php echo $txtback; ?>
                            </a>
                        </li>
                    </ul>
                </div>			
			</div>			
			
			<div data-role="popup" id="ficha_producto" data-theme="a" data-position-to="window" class="ui-content">
			
			</div>
			
			
	
			
<script>

var abiertos = new Array();
abiertos[0] = 'inicio';
	
	function showcatalogo(id)
		{
		for (i=0;i<abiertos.length;i++)
			{
			if (abiertos[i]==id)
				{
				$('#p'+abiertos[i]).empty();
				abiertos[i]= 'nulo';
				}
			}
		var encontrado = 'N';
		if (encontrado == 'Y')
			{
			 $('#'+id).empty();
			 $('#p'+id).empty();
			}
		else
			{
			if (id != 'busqueda')	
				{
				$('#'+id).load
					(
					'./sub_categorias.php',
					{
					padre: id
					},
					function() 
						{
						$('#'+id).trigger('create');
						}
					);	
				}

			$('#p'+id).load
				(
				'./productos.php',
				{
				padre: id,
				busqueda: $('#busqueda').attr('value'),
				id_venta:<?php echo $_POST['id_venta']; ?>
				},
				function() 
					{
					$('#p'+id).trigger('create');
					abiertos[abiertos.length] = id;
					//$.mobile.silentScroll($('#'+id).offset().top);
					}
				);	
			}
		}
		
		
	function plusone(id)
		{
		contador = contador + 1;
		if (contador == 11) {contador = 0;}
		$('#operaciones'+contador).load
			(
			'./save_producto.php',
			{
			add_producto: id,
			cantidad: 1,
			id_venta:<?php echo $_POST['id_venta']; ?>
			},
			function() 
				{
				$('#link'+id).prepend('<img src="./images/ok.png"/>');
				}
			);			
		}
		
	function ficha_producto(id)
		{
		$('#ficha_producto').load
			(
			'./add_producto.php',
			{
			producto: id,
			id_venta:<?php echo $_POST['id_venta']; ?>
			},
			function() 
				{
				$('#ficha_producto').trigger('create');
				$('#ficha_producto').popup('open');
				}
			);			
		}
		
		
</script>


 
<?php 
session_start();
if (!isset($_SESSION['id_camarero']))
	{
	exit(); 
	}
include "./conn.php";
include "./funciones.php";

	// a?ade producto
	// si es combinado cambia el id del producto
	if (isset($_POST['combinado']) and $_POST['combinado'] <> 'no') { $_POST['add_producto'] = $_POST['combinado']; }
	// nuevo id_linea
	$result = mysql_query("select 1+max(id_linea) as nuevo_id from ventadir_comg where id_venta = ".$_POST['id_venta']." order by id_linea desc limit 1",$conexion);
	$row = mysql_fetch_array($result);
	if (isset($row['nuevo_id']))
		{
		$id_linea = $row['nuevo_id'];
		}
	else
		{
		$id_linea = 1;
		}
		
	// precios
	$result = mysql_query("select id_tipo_comg,complementog,precio,avgIva,(precio * (1 + (avgIva/100))) as pvp,cocina from complementog where id_complementog = '".$_POST['add_producto']."'",$conexion);
	$row = mysql_fetch_array($result);
	// nombre del producto
	$producto = $row['complementog'];
	// aqui comprueba si existe otra tarifa por la mesa o sesi?n ( sesi?n mas adelante)
		$result2 = mysql_query("select pvptarifa from comg_tarifa where id_complementog = '".$_POST['add_producto']."' and id_tarifa in (select id_tarifa from mesa where Num_Mesa in (select Num_Mesa from ventadirecta where id_venta = ".$_POST['id_venta']."))",$conexion);
		if (mysql_num_rows($result2) > 0)
			{
			$row2 = mysql_fetch_array($result2);
			$row['pvp'] = $row2['pvptarifa'];
			$row['precio'] = $row['pvp'] / (1 + ($row['avgIva']/100));
			}
	// bloque de cocina
	if (!isset($_POST['bloque_cocina'])) { $_POST['bloque_cocina'] = '1'; }
	// si el producto es susceptible de tener opciones de cocina
	if (!isset($_POST['opciones'])) { $_POST['opciones'] = ''; }
	if ($row['cocina'] == 'Y')
		{
		// obten opciones de cocina
		$result2 = mysql_query("select * from notacocina",$conexion);
		while ($row2 = mysql_fetch_array($result2))
			{
			if (isset($_POST[$row2['id_nota']]))
				{
				$_POST['opciones'] = $_POST['opciones'].' * '.$row2['nota'];
				}
			}
		}
	// inserta
	if (!isset($_POST['observaciones'])) { $_POST['observaciones'] = ''; }
	$sql = "insert into ventadir_comg (id_complementog,id_venta,cantidad,id_tipo_comg,id_empresa,id_linea,id_centro,PVPTiquet,precio,avgiva,descuento,destino,id_almacen,cocina,complementog,total,nota,observaciones,bloque_cocina)";
	$sql = $sql." values ('".$_POST['add_producto']."',".$_POST['id_venta'].",".$_POST['cantidad'].",'".$row['id_tipo_comg']."','001',".$id_linea.",'01',".$row['pvp'].",".$row['precio'].",".$row['avgIva'].",0,'V','".$_SESSION['id_almacen']."',0,'".$row['complementog']."',".$row['pvp'].",'".$_POST['opciones']."','".$_POST['observaciones']."',".$_POST['bloque_cocina'].")";
	//echo $sql;
	$result = mysql_query($sql,$conexion);
	// resta stock
	restastock($_POST['add_producto'],$_POST['cantidad']);
	
	// opciones de tipo de combinado 2 y 3
	$result = mysql_query("select tipo_combinado from complementog where id_complementog = '".$_POST['add_producto']."'",$conexion);
	$row = mysql_fetch_array($result);
	if ($row['tipo_combinado'] <> '1')
		{
		$cnt=0;
		$result2 = mysql_query("select p.id_tipo_comg as id_tipo_comg,p.complementog as complementog,c.id_complementog1 as id_complementog1,c.precio as precio,p.avgiva as avgiva from combinados c,complementog p where p.id_complementog = c.id_complementog1 and c.id_complementog = '".$_POST['add_producto']."'",$conexion);
		while ($row2 = mysql_fetch_array($result2))
			{
			if (isset($_POST[$row2['id_complementog1']]))
				{
				$cnt=$cnt+1;
				if ($row['tipo_combinado'] == '2')
					{
					$precio = 0;
					$pvp = 0;
					}
				if ($row['tipo_combinado'] == '3')
					{
					$precio = $row2['precio'] / (1 + ($row2['avgiva']/100));
					$pvp = $row2['precio'];
					}
					
				// inserta
				$sql = "insert into ventadir_comg (id_complementog,id_venta,cantidad,id_tipo_comg,id_empresa,id_linea,id_centro,PVPTiquet,precio,avgiva,descuento,destino,id_almacen,cocina,complementog,total,nota,observaciones,bloque_cocina)";
				$sql = $sql." values ('".$row2['id_complementog1']."',".$_POST['id_venta'].",".$_POST['cantidad'].",'".$row2['id_tipo_comg']."','001',".($id_linea + $cnt).",'01',".$pvp.",".$precio.",".$row2['avgiva'].",0,'V','".$_SESSION['id_almacen']."',0,'-->".$row2['complementog']."',".$pvp.",'','',".$_POST['bloque_cocina'].")";
				$result3 = mysql_query($sql,$conexion);
				// resta stock
				restastock($row2['id_complementog1'],$_POST['cantidad']);
				}
			}
		}
	//echo $producto." insertado Ok.";
	
?>